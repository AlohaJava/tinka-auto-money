rootProject.name = "tinka-invest"
