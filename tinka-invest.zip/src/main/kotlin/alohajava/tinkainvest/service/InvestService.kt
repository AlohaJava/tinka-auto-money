package alohajava.tinkainvest.service

import alohajava.tinkainvest.configuration.properties.CronSettings
import kotlinx.coroutines.delay
import kotlinx.coroutines.future.await
import mu.KLogging
import org.springframework.stereotype.Service
import ru.tinkoff.piapi.contract.v1.OrderDirection
import ru.tinkoff.piapi.contract.v1.OrderType
import ru.tinkoff.piapi.contract.v1.Quotation
import ru.tinkoff.piapi.core.InvestApi
import ru.tinkoff.piapi.core.exception.ApiRuntimeException
import java.util.*

@Service
class InvestService(
    private val investApi: InvestApi,
    private val telegramService: TelegramService?
) {
    companion object : KLogging() {
        private val DEFAULT_QUOTATION = Quotation.newBuilder().setUnits(5).build()
    }

    suspend fun makeProkrut(cronSettings: CronSettings) = with(cronSettings) {
        telegramService?.sendMessage("Начал прокрутку с $figi, количество $buyCount")
        val accountId = investApi.userService.accounts.await().first().id

        repeat(repeatCount) {
            createOrder(figi, buyCount, OrderDirection.ORDER_DIRECTION_BUY, accountId)
            delay(delayMillis)
            createOrder(figi, buyCount, OrderDirection.ORDER_DIRECTION_SELL, accountId)
        }
        telegramService?.sendMessage("Сделал прокрутку с $figi, количество $buyCount")
    }

    private suspend fun createOrder(
        figi: String,
        quantity: Long,
        direction: OrderDirection,
        accountId: String
    ) {
        try {
            investApi.ordersService.postOrder(
                figi,
                quantity,
                DEFAULT_QUOTATION,
                direction,
                accountId,
                OrderType.ORDER_TYPE_MARKET,
                UUID.randomUUID().toString()
            ).await()
        } catch (e: ApiRuntimeException) {
            telegramService?.sendMessage( "Ошибка создания order для figi: $figi, ${e.message}")
            throw e
        }
    }
}
