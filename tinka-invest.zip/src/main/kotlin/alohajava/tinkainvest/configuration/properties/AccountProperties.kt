package alohajava.tinkainvest.configuration.properties

import org.springframework.boot.context.properties.ConfigurationProperties

@ConfigurationProperties(prefix = "account")
data class AccountProperties(
    val token: String,
    val cronSettings: List<CronSettings>
)

data class CronSettings(
    val cron: String,
    val buyCount: Long,
    val figi: String,
    val repeatCount: Int,
    val delayMillis: Long
)