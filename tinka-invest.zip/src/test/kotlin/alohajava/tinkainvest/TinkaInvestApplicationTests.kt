package alohajava.tinkainvest

class TinkaInvestApplicationTests {}
